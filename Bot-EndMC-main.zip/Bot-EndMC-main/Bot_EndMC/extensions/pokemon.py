import requests
from discord.ext import commands
from discord import app_commands, Embed
import discord
from discord.ui import Button, View

class PokedexBot(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def fetch_data(self, url):
        response = requests.get(url)
        return response.json() if response.status_code == 200 else None

    def add_field_with_limit(self, embed, name, value):
        max_length = 1024
        if len(value) > max_length:
            for chunk in [value[i:i + max_length] for i in range(0, len(value), max_length)]:
                embed.add_field(name=name, value=chunk, inline=False)
        else:
            embed.add_field(name=name, value=value, inline=False)

    @app_commands.command(name="pokedex", description="Obtenez des informations sur un Pokémon.")
    async def pokedex(self, interaction: discord.Interaction, pokemon_name: str):
        await interaction.response.defer()

        data = self.fetch_data(f"https://pokeapi.co/api/v2/pokemon/{pokemon_name.lower()}")
        species_data = self.fetch_data(f"https://pokeapi.co/api/v2/pokemon-species/{pokemon_name.lower()}")

        if data and species_data:
            embed = Embed(title=f"{data['name'].capitalize()} | #{data['id']}", color=0x1F8B4C)
            embed.set_thumbnail(url=data['sprites']['front_default'])

            types = ", ".join([t['type']['name'] for t in data['types']])
            abilities = ", ".join([a['ability']['name'] for a in data['abilities']])

            weaknesses = set()
            for t in data['types']:
                type_data = self.fetch_data(t['type']['url'])
                if type_data:
                    weaknesses.update([weak_type['name'] for weak_type in type_data['damage_relations']['double_damage_from']])
            weaknesses = ", ".join(weaknesses)

            capture_rate = species_data.get('capture_rate', 'Inconnu')
            egg_groups = ", ".join([egg_group['name'] for egg_group in species_data.get('egg_groups', [])])

            self.add_field_with_limit(embed, "📊 À propos", (
                f"**Espèce**: {species_data.get('genera')[7]['genus'] if 'genera' in species_data else 'Inconnue'}\n"
                f"**Capacités**: {abilities}\n"
                f"**Couleur**: {species_data.get('color', {}).get('name', 'Inconnue').capitalize()}\n"
                f"**Taux de Capture**: {capture_rate}%\n"
                f"**Habitat**: {species_data.get('habitat', {}).get('name', 'Inconnu').capitalize()}\n"
                f"**Types**: {types}"
            ))

            self.add_field_with_limit(embed, "🧬 Reproduction", (
                f"**Groupes d'Œufs**: {egg_groups if egg_groups else 'Inconnu'}"
            ))

            self.add_field_with_limit(embed, "⚔️ Faiblesses", weaknesses or "Aucune")

            view = View()
            stats_button = Button(label="Voir les stats", style=discord.ButtonStyle.success)
            view.add_item(stats_button)

            async def show_stats_button_callback(interaction: discord.Interaction):
                await self.show_stats(interaction, pokemon_name)

            stats_button.callback = show_stats_button_callback

            await interaction.followup.send(embed=embed, view=view)
        else:
            await interaction.followup.send(f"Pokémon Inconnu '{pokemon_name}'.")

    async def show_stats(self, interaction: discord.Interaction, pokemon_name: str):
        data = self.fetch_data(f"https://pokeapi.co/api/v2/pokemon/{pokemon_name.lower()}")

        if data:
            embed = Embed(title=f"{data['name'].capitalize()} | #{data['id']}", color=0x1F8B4C)
            embed.set_thumbnail(url=data['sprites']['front_default'])

            stats = {stat['stat']['name']: stat['base_stat'] for stat in data['stats']}
            max_stats = {
                'hp': 255,
                'attack': 190,
                'defense': 250,
                'special-attack': 154,
                'special-defense': 250,
                'speed': 150
            }

            stat_fields = [
                ("Attaque", stats['attack'], max_stats['attack']),
                ("Défense", stats['defense'], max_stats['defense']),
                ("Vitesse", stats['speed'], max_stats['speed']),
                ("HP", stats['hp'], max_stats['hp']),
                ("Sp. Attaque", stats['special-attack'], max_stats['special-attack']),
                ("Sp. Défense", stats['special-defense'], max_stats['special-defense'])
            ]

            stat_embed_fields = ""
            for stat_name, stat_value, stat_max in stat_fields:
                bar = '🟧' * int(30 * stat_value / stat_max)
                stat_embed_fields += f"**{stat_name}**: {stat_value} / {stat_max}\n{bar}\n\n"

            self.add_field_with_limit(embed, "⚔️ Statistiques", stat_embed_fields)

            await interaction.response.send_message(embed=embed)
        else:
            await interaction.response.send_message(f"Pokémon inconnu '{pokemon_name}'.")

async def setup(bot):
    await bot.add_cog(PokedexBot(bot))
